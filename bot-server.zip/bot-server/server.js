// Server kontrol bot musik. Tanpa dependensi, butuh Node.js 18+.
// Fungsinya: menyimpan data room, menerima perintah dari dashboard, mencatat masa aktif,
// dan memanggil "adapter" untuk memasukkan / mengeluarkan bot dari ruangan.
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = parseInt(process.env.PORT || '3000', 10);
const API_KEY = process.env.API_KEY || '';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';      // contoh: https://domainmu.com
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const DAY = 86400000;

if (API_KEY.length < 16) {
  console.error('API_KEY wajib diisi minimal 16 karakter (lihat .env.example).');
  process.exit(1);
}

const adapter = require(process.env.ADAPTER === 'mock' ? './adapter-mock' : './adapter');

// ===== penyimpanan (file JSON) =====
let db = { rooms: {} };
try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { /* mulai kosong */ }
function save() {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}
const now = () => Date.now();
const log = (...a) => console.log(new Date().toISOString(), ...a);

// ===== logika bot =====
async function activate(room, months) {
  room.status = 'activating'; room.lastError = null; save();
  try {
    await adapter.join(room);
    const base = Math.max(now(), room.premiumUntil ? Date.parse(room.premiumUntil) : 0);
    room.premiumUntil = new Date(base + months * 30 * DAY).toISOString();
    room.status = 'active';
    log('aktif', room.id, room.name);
  } catch (e) {
    room.status = 'error'; room.lastError = String(e.message || e).slice(0, 300);
    log('gagal aktif', room.id, room.lastError);
  }
  save();
}
async function deactivate(room, finalStatus) {
  try { await adapter.leave(room); room.lastError = null; }
  catch (e) { room.lastError = String(e.message || e).slice(0, 300); }
  room.status = finalStatus || 'inactive';
  if (finalStatus === 'inactive') room.premiumUntil = null;
  save();
  log('nonaktif', room.id, room.status);
}

// Cek masa aktif tiap menit
setInterval(async () => {
  for (const room of Object.values(db.rooms)) {
    if (room.status === 'active' && room.premiumUntil && Date.parse(room.premiumUntil) <= now()) {
      await deactivate(room, 'expired');
    }
  }
}, 60 * 1000);

// Setelah server restart, masukkan lagi bot yang masih dalam masa aktif
(async () => {
  for (const room of Object.values(db.rooms)) {
    if (room.status === 'active' && Date.parse(room.premiumUntil) > now()) {
      try { await adapter.join(room); log('masuk ulang', room.id); }
      catch (e) { room.status = 'error'; room.lastError = String(e.message || e).slice(0, 300); save(); }
    }
  }
})();

// ===== HTTP =====
function send(res, code, body, origin) {
  const h = { 'Content-Type': 'application/json; charset=utf-8', 'X-Content-Type-Options': 'nosniff' };
  if (ALLOWED_ORIGIN && origin === ALLOWED_ORIGIN) {
    h['Access-Control-Allow-Origin'] = origin;
    h['Vary'] = 'Origin';
    h['Access-Control-Allow-Headers'] = 'Content-Type, X-API-Key';
    h['Access-Control-Allow-Methods'] = 'GET, POST, DELETE, OPTIONS';
  }
  res.writeHead(code, h); res.end(JSON.stringify(body));
}
function authed(req) {
  const given = Buffer.from(String(req.headers['x-api-key'] || ''));
  const real = Buffer.from(API_KEY);
  return given.length === real.length && crypto.timingSafeEqual(given, real);
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0, chunks = [];
    req.on('data', c => { size += c.length; if (size > 10240) { reject(new Error('Body terlalu besar')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch (e) { reject(new Error('JSON tidak valid')); } });
  });
}
const view = r => ({ id: r.id, name: r.name, url: r.url, botName: r.botName, status: r.status,
  premiumUntil: r.premiumUntil, lastError: r.lastError });

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  try {
    const url = new URL(req.url, 'http://x');
    const parts = url.pathname.split('/').filter(Boolean);

    if (req.method === 'OPTIONS') return send(res, 204, {}, origin);
    if (url.pathname === '/health') return send(res, 200, { ok: true }, origin);
    if (!authed(req)) return send(res, 401, { error: 'API key salah atau tidak ada' }, origin);

    if (parts[0] !== 'rooms') return send(res, 404, { error: 'Tidak ditemukan' }, origin);

    if (parts.length === 1 && req.method === 'GET')
      return send(res, 200, Object.values(db.rooms).map(view), origin);

    if (parts.length === 1 && req.method === 'POST') {
      const b = await readJson(req);
      const name = String(b.name || '').trim().slice(0, 60);
      const botName = String(b.botName || '').trim().slice(0, 40);
      const link = String(b.url || '').trim().slice(0, 300);
      if (!name || !botName) return send(res, 400, { error: 'name dan botName wajib diisi' }, origin);
      if (link && !/^https?:\/\//i.test(link)) return send(res, 400, { error: 'url harus diawali http(s)://' }, origin);
      const id = crypto.randomUUID();
      db.rooms[id] = { id, name, url: link, botName, status: 'inactive', premiumUntil: null, lastError: null };
      save();
      return send(res, 201, view(db.rooms[id]), origin);
    }

    const room = db.rooms[parts[1]];
    if (!room) return send(res, 404, { error: 'Room tidak ditemukan' }, origin);

    if (parts.length === 3 && parts[2] === 'activate' && req.method === 'POST') {
      const b = await readJson(req);
      const months = parseInt(b.months, 10);
      if (![1, 3, 6].includes(months)) return send(res, 400, { error: 'months harus 1, 3, atau 6' }, origin);
      await activate(room, months);
      return send(res, room.status === 'active' ? 200 : 502, view(room), origin);
    }
    if (parts.length === 3 && parts[2] === 'deactivate' && req.method === 'POST') {
      await deactivate(room, 'inactive');
      return send(res, 200, view(room), origin);
    }
    if (parts.length === 2 && req.method === 'DELETE') {
      await deactivate(room, 'inactive'); delete db.rooms[room.id]; save();
      return send(res, 200, { deleted: true }, origin);
    }
    return send(res, 404, { error: 'Tidak ditemukan' }, origin);
  } catch (e) {
    return send(res, 400, { error: String(e.message || e) }, origin);
  }
});

server.listen(PORT, () => log('Server berjalan di port', PORT, '| adapter:', process.env.ADAPTER || 'imvu'));
process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
