# Server kontrol bot musik

Server kecil (Node.js, tanpa dependensi) untuk menyimpan data room, menerima perintah dari
dashboard, mencatat masa aktif, dan memanggil adapter yang memasukkan/mengeluarkan bot dari ruangan.

## Yang SUDAH ada
- API: daftar room, tambah room, aktifkan (1/3/6 bulan), nonaktifkan, hapus
- Pencatatan masa aktif dan pengecekan kedaluwarsa tiap menit
- Bot dimasukkan lagi otomatis setelah server restart
- Autentikasi dengan API key, batas ukuran request, CORS terbatas ke satu alamat

## Yang BELUM ada
- `adapter.js` (bagian yang benar-benar masuk ke ruangan IMVU) sengaja masih kosong.
  Isi hanya setelah IMVU mengizinkan akun bot dan Anda tahu cara masuk yang diizinkan,
  atau sambungkan ke layanan bot pihak lain yang punya API. Tanpa itu, tombol aktifkan
  akan berstatus `error` dengan pesan yang jelas.

## Coba di komputer sendiri (adapter palsu)
```
API_KEY=ganti-dengan-kunci-acak-16-karakter ADAPTER=mock node server.js
curl localhost:3000/health
```

## Pasang di server 24 jam (VPS Ubuntu)
1. Sewa VPS kecil (penyedia mana pun) dan login lewat SSH.
2. Pasang Node.js 18+ (`sudo apt install nodejs` atau lewat nodesource).
3. Salin folder ini ke `/opt/bot-server`, lalu `cp .env.example .env` dan isi `API_KEY`
   (buat dengan `openssl rand -hex 24`) dan `ALLOWED_ORIGIN`.
4. Buat user: `sudo useradd -r botsrv && sudo chown -R botsrv /opt/bot-server`
5. `sudo cp bot-server.service /etc/systemd/system/ && sudo systemctl enable --now bot-server`
6. Cek: `systemctl status bot-server` dan `curl localhost:3000/health`
7. Pasang HTTPS dengan Caddy atau Nginx di depan port 3000 (wajib, supaya API key tidak
   terkirim polos). Contoh Caddyfile: `api.domainmu.com { reverse_proxy localhost:3000 }`

Alternatif Docker: `docker build -t bot-server .` lalu
`docker run -d --restart=always -p 3000:3000 -v botdata:/data --env-file .env bot-server`

## Endpoint (semua kecuali /health butuh header `X-API-Key`)
| Metode | Path | Isi |
| --- | --- | --- |
| GET | /health | Cek server hidup |
| GET | /rooms | Daftar room |
| POST | /rooms | `{name, botName, url?}` tambah room |
| POST | /rooms/:id/activate | `{months: 1\|3\|6}` aktifkan bot |
| POST | /rooms/:id/deactivate | Nonaktifkan bot |
| DELETE | /rooms/:id | Hapus room |

Status room: `inactive`, `activating`, `active`, `expired`, `error` (lihat `lastError`).

## Keamanan (penting)
- JANGAN menaruh API key di `dashboard.html` yang bisa dibuka orang lain. Siapa pun yang
  membuka halaman bisa melihat kuncinya dan mengendalikan bot Anda. Pakai API ini dari
  dashboard khusus admin yang dilindungi login, atau dari server Anda sendiri.
- Simpan kata sandi akun bot di `.env` di server, bukan di kode atau HTML.
- Cadangkan `data.json` secara berkala.
