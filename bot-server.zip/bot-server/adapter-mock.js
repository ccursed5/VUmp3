// Adapter palsu untuk menguji server tanpa IMVU: ADAPTER=mock node server.js
// TIDAK memasukkan bot ke ruangan sungguhan, hanya mencatat di log.
'use strict';
module.exports = {
  async join(room)  { console.log('[mock] bot masuk ke', room.name); },
  async leave(room) { console.log('[mock] bot keluar dari', room.name); }
};
