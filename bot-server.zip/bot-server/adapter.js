// ADAPTER IMVU: bagian yang benar-benar memasukkan bot ke ruangan.
//
// SENGAJA BELUM DIISI. Saya tidak punya dokumentasi resmi atau izin dari IMVU untuk
// akun bot otomatis, jadi tidak ada kode login ke IMVU di sini. Isi dua fungsi di bawah
// HANYA setelah:
//   1. IMVU mengonfirmasi bahwa akun bot dan program otomatis diizinkan, dan
//   2. Anda tahu cara resmi / yang diizinkan untuk masuk ke ruangan (atau Anda memakai
//      layanan bot pihak lain yang menyediakan API kontrol).
//
// Kontrak:
//   join(room)  -> resolve kalau bot sudah masuk ke room; throw Error kalau gagal.
//   leave(room) -> resolve kalau bot sudah keluar; throw Error kalau gagal.
// `room` berisi: id, name, url, botName.
//
// Simpan kredensial akun bot di environment variable (file .env), jangan di kode ini.
'use strict';

async function join(room) {
  throw new Error('Adapter IMVU belum diimplementasikan (lihat adapter.js)');
}

async function leave(room) {
  throw new Error('Adapter IMVU belum diimplementasikan (lihat adapter.js)');
}

module.exports = { join, leave };
